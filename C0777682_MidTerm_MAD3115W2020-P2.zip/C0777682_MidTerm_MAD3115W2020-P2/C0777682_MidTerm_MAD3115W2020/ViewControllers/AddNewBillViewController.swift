//
//  AddNewBillViewController.swift
//  C0777682_MidTerm_MAD3115W2020
//
//  Created by MacStudent on 2020-03-09.
//  Copyright © 2020 MacStudent. All rights reserved.
//

import UIKit

class AddNewBillViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    

    /*let customerListVC = self.navigationController?.viewControllers[1] as! CustomerListViewController
          self.navigationController?.popToViewController(customerListVC, animated: true)*/
   
    @IBAction func btnSaveCustomer(_ sender: UIBarButtonItem)
    {
    }
}
