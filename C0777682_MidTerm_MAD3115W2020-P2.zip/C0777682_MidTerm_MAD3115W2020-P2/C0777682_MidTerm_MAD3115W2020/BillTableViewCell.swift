//
//  HydroTableViewCllTableViewCell.swift
//  C0777682_MidTerm_MAD3115W2020
//
//  Created by MacStudent on 2020-03-10.
//  Copyright © 2020 MacStudent. All rights reserved.
//

import UIKit

class BillTableViewCell: UITableViewCell {
    
    @IBOutlet weak var lblBillID: UILabel!
    
    @IBOutlet weak var lblBillDate: UILabel!
  
    @IBOutlet weak var lblBillType: UILabel!
    @IBOutlet weak var lblBillAmount: UILabel!
    
}
